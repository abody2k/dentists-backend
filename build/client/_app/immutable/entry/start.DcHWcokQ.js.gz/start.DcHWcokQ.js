import{a as t}from"../chunks/entry.Bed20FVa.js";export{t as start};
