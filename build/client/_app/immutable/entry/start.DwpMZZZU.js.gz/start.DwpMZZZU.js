import{a as t}from"../chunks/entry.D7NOhxnJ.js";export{t as start};
