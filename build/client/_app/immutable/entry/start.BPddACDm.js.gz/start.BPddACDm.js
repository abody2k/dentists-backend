import{a as t}from"../chunks/entry.DdaFbcUs.js";export{t as start};
