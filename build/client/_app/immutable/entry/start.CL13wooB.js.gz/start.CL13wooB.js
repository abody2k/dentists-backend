import{a as t}from"../chunks/entry.BMiL1vRG.js";export{t as start};
