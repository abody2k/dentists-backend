import{a as t}from"../chunks/entry.BG4KLvOP.js";export{t as start};
