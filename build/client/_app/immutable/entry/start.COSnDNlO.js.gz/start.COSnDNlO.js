import{a as t}from"../chunks/entry.B7wcGlki.js";export{t as start};
