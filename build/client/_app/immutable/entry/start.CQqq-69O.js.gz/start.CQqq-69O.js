import{a as t}from"../chunks/entry.DCoa5QMu.js";export{t as start};
