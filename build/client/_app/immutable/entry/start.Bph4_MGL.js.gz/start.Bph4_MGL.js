import{a as t}from"../chunks/entry.Dwr23cDU.js";export{t as start};
