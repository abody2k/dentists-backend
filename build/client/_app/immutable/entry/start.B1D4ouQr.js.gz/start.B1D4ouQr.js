import{a as t}from"../chunks/entry.Ge-qZmAu.js";export{t as start};
