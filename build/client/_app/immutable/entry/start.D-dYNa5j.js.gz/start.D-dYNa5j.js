import{a as t}from"../chunks/entry.6m0mmhjH.js";export{t as start};
