import{a as t}from"../chunks/entry.4dhhw7bk.js";export{t as start};
