import{a as t}from"../chunks/entry.Cp2Lix93.js";export{t as start};
