import{a as t}from"../chunks/entry.bQq5HXS6.js";export{t as start};
