import{a as t}from"../chunks/entry.CSG3s756.js";export{t as start};
