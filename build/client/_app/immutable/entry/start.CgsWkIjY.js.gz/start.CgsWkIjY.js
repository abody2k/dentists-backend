import{a as t}from"../chunks/entry.F0Rf4B2-.js";export{t as start};
