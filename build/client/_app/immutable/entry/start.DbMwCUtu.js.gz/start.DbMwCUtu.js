import{a as t}from"../chunks/entry.DojzKn0V.js";export{t as start};
