import{a as t}from"../chunks/entry.WrPclY24.js";export{t as start};
