import{a as t}from"../chunks/entry.Ck53wsY4.js";export{t as start};
