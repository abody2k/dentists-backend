import{a as t}from"../chunks/entry.FgZLFe1E.js";export{t as start};
