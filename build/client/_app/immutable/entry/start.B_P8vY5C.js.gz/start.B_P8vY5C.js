import{a as t}from"../chunks/entry.DFm27DCu.js";export{t as start};
