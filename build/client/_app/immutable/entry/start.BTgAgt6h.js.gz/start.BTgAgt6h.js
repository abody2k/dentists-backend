import{a as t}from"../chunks/entry.JFxvUfpY.js";export{t as start};
