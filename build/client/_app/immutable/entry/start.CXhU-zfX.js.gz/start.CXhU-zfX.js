import{a as t}from"../chunks/entry.C9Q0Zln8.js";export{t as start};
