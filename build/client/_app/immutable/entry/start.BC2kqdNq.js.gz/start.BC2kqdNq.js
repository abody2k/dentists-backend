import{a as t}from"../chunks/entry.vTTl0Xqn.js";export{t as start};
