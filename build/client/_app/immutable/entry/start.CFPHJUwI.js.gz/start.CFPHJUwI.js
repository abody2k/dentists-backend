import{a as t}from"../chunks/entry.LgM9fU2C.js";export{t as start};
