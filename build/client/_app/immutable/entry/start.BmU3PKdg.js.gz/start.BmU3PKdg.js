import{a as t}from"../chunks/entry.bqJyX4ZI.js";export{t as start};
