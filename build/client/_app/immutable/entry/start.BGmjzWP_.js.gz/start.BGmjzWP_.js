import{a as t}from"../chunks/entry.BhmmBOkz.js";export{t as start};
