import{a as t}from"../chunks/entry.D3PRw3pZ.js";export{t as start};
