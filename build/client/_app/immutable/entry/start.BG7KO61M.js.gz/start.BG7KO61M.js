import{a as t}from"../chunks/entry._KZ9QnE8.js";export{t as start};
