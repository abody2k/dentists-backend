import{a as t}from"../chunks/entry.DFTuGyNv.js";export{t as start};
