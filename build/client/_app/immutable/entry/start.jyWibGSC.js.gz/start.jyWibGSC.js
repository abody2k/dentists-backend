import{a as t}from"../chunks/entry.CRkNe6pY.js";export{t as start};
