import{a as t}from"../chunks/entry.4TrfvYrK.js";export{t as start};
