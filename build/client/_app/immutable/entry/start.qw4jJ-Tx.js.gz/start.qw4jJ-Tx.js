import{a as t}from"../chunks/entry.DxxijvSv.js";export{t as start};
