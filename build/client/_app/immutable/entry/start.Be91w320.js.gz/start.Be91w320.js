import{a as t}from"../chunks/entry.B6rLXjpT.js";export{t as start};
