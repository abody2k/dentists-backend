import{a as t}from"../chunks/entry.BmNi8hWF.js";export{t as start};
