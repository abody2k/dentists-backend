import{a as t}from"../chunks/entry.BNrxvcpK.js";export{t as start};
