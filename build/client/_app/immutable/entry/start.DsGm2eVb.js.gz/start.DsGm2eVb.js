import{a as t}from"../chunks/entry.CPSoe7h1.js";export{t as start};
