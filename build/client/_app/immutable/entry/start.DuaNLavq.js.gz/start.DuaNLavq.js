import{a as t}from"../chunks/entry.CUxa_M6q.js";export{t as start};
