import{a as t}from"../chunks/entry.ChcusuLs.js";export{t as start};
