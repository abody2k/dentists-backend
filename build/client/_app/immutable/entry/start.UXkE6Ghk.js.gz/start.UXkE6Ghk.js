import{a as t}from"../chunks/entry.Bo_jiDz2.js";export{t as start};
