import{a as t}from"../chunks/entry.Ca1UpYE9.js";export{t as start};
