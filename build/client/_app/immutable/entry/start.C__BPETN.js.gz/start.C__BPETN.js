import{a as t}from"../chunks/entry.C1mUusia.js";export{t as start};
