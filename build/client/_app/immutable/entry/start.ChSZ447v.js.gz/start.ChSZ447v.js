import{a as t}from"../chunks/entry.BUCqzFcr.js";export{t as start};
