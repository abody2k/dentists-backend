import{a as t}from"../chunks/entry.dlaHsruo.js";export{t as start};
