import{a as t}from"../chunks/entry.BDVTD4vY.js";export{t as start};
