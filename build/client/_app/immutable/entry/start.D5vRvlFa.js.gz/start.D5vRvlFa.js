import{a as t}from"../chunks/entry.B2fP__Uf.js";export{t as start};
