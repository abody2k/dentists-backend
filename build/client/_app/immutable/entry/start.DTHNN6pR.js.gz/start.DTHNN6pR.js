import{a as t}from"../chunks/entry.d4a49XB8.js";export{t as start};
