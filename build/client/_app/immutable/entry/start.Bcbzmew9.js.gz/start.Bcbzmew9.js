import{a as t}from"../chunks/entry.3gZYhxtV.js";export{t as start};
