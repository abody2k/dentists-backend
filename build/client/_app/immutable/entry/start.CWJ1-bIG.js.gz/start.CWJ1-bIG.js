import{a as t}from"../chunks/entry.BOCok8zK.js";export{t as start};
