import{a as t}from"../chunks/entry.DV3Z-F08.js";export{t as start};
