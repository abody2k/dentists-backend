import{a as t}from"../chunks/entry.Byrc7V5D.js";export{t as start};
