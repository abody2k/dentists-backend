import{a as t}from"../chunks/entry.DWvNla3_.js";export{t as start};
