import{a as t}from"../chunks/entry.DcAxyUp_.js";export{t as start};
