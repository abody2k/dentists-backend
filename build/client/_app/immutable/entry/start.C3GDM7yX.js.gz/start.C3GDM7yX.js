import{a as t}from"../chunks/entry.yOjpE30R.js";export{t as start};
