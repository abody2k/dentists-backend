import{a as t}from"../chunks/entry.B8-yWps4.js";export{t as start};
