import{a as t}from"../chunks/entry.DtFghkqd.js";export{t as start};
