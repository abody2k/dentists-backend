import{a as t}from"../chunks/entry.r7Vd5oIu.js";export{t as start};
