import{a as t}from"../chunks/entry.DtG7I3RA.js";export{t as start};
