import{a as t}from"../chunks/entry.CEJBLA0A.js";export{t as start};
