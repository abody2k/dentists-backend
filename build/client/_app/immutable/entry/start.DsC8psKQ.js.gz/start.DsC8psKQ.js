import{a as t}from"../chunks/entry.BKImVG1A.js";export{t as start};
