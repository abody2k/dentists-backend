import{a as t}from"../chunks/entry.Erngbb9B.js";export{t as start};
