import{a as t}from"../chunks/entry.7jvu7s5E.js";export{t as start};
