import{a as t}from"../chunks/entry.BQnskFtK.js";export{t as start};
