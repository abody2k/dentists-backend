import{a as t}from"../chunks/entry.CS0UZUDK.js";export{t as start};
