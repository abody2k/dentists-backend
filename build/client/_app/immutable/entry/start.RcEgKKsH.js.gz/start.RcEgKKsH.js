import{a as t}from"../chunks/entry.BU7CfaAl.js";export{t as start};
