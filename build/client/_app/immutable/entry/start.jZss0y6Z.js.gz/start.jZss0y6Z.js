import{a as t}from"../chunks/entry.DVDwI1j5.js";export{t as start};
