import{a as t}from"../chunks/entry.Dp3oGBM6.js";export{t as start};
