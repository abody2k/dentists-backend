import{a as t}from"../chunks/entry.xcoi-_SP.js";export{t as start};
