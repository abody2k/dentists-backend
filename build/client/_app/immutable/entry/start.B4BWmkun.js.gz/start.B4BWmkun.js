import{a as t}from"../chunks/entry.DP5LAkOI.js";export{t as start};
