import{a as t}from"../chunks/entry.CTN5WZ9H.js";export{t as start};
