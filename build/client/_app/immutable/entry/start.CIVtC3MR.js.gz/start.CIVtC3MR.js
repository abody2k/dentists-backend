import{a as t}from"../chunks/entry.Bh8ax4ks.js";export{t as start};
